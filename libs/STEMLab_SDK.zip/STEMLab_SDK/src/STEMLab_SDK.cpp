#include "STEMLab_SDK.h"
#include <string>

STEMLab_SDK::STEMLab_SDK(int newBaudrate, float newProtocol) {
	baudrate = newBaudrate;
	protocol = newProtocol;
};

void STEMLab_SDK::init() {
	portHandler = dynamixel::PortHandler::getPortHandler("3");
	packetHandler = dynamixel::PacketHandler::getPacketHandler(protocol);
	packetHandler1P = dynamixel::PacketHandler::getPacketHandler(1.0);
	packetHandler2P = dynamixel::PacketHandler::getPacketHandler(2.0);
	portHandler->openPort();
	portHandler->setBaudRate(baudrate);
};

void STEMLab_SDK::changeBaudrateOnPort(int newBaudrate) {
	baudrate = newBaudrate;
	portHandler->setBaudRate(newBaudrate);
};

void STEMLab_SDK::changeBaudrate(uint8_t id, uint16_t reg, uint32_t baudrate) {
	if (reg == 8) {
		switch (baudrate) {
			case 57600:
				write1Byte(id, reg, 1);
				break;
			case 115200:
				write1Byte(id, reg, 2);
				break;
			case 1000000:
				write1Byte(id, reg, 3);
				break;
		}
	}
	else if (reg == 4) {
		switch (baudrate) {
			case 57600:
				write1Byte(id, reg, 34);
				break;
			case 115200:
				write1Byte(id, reg, 16);
				break;
			case 1000000:
				write1Byte(id, reg, 1);
				break;
		}
	}
}

void STEMLab_SDK::changeId(uint8_t id, uint16_t idReg, uint8_t newId) {
	write1Byte(id, idReg, newId);
};

void STEMLab_SDK::changeProtocolOnPort(float newProtocol) {
	packetHandler = dynamixel::PacketHandler::getPacketHandler(newProtocol);
	protocol = newProtocol;
};

void STEMLab_SDK::changeProtocol(uint8_t newId, float newProtocol) {
	write1Byte(newId, 13, newProtocol);
}

uint8_t STEMLab_SDK::read1Byte(uint8_t id, uint16_t reg) {
	uint8_t data = 0;
	packetHandler->read1ByteTxRx(portHandler, id, reg, (uint8_t*)&data);
	return data;
};

uint8_t STEMLab_SDK::read1Byte(uint8_t id, uint16_t reg, float protocol) {
	uint8_t data = 0;

	if (protocol == 2.0){
		packetHandler2P->read1ByteTxRx(portHandler, id, reg, (uint8_t*)&data);
	}
	else{
		packetHandler1P->read1ByteTxRx(portHandler, id, reg, (uint8_t*)&data);
	}
	
	return data;
};

uint16_t STEMLab_SDK::read2Byte(uint8_t id, uint16_t reg) {
	uint16_t data = 0;
	packetHandler->read2ByteTxRx(portHandler, id, reg, (uint16_t*)&data);
	return data;
};

uint16_t STEMLab_SDK::read2Byte(uint8_t id, uint16_t reg, float protocol) {
	uint16_t data = 0;

	if (protocol == 2.0){
		packetHandler2P->read2ByteTxRx(portHandler, id, reg, (uint16_t*)&data);
	}
	else{
		packetHandler1P->read2ByteTxRx(portHandler, id, reg, (uint16_t*)&data);
	}

	return data;
};

uint32_t STEMLab_SDK::read4Byte(uint8_t id, uint16_t reg) {
	uint32_t data = 0;
	packetHandler->read4ByteTxRx(portHandler, id, reg, (uint32_t*)&data);
	return data;
};

uint32_t STEMLab_SDK::read4Byte(uint8_t id, uint16_t reg, float protocol) {
	uint32_t data = 0;

	if (protocol == 2.0){
		packetHandler2P->read4ByteTxRx(portHandler, id, reg, (uint32_t*)&data);
	}
	else{
		packetHandler1P->read4ByteTxRx(portHandler, id, reg, (uint32_t*)&data);
	}

	return data;
};

void STEMLab_SDK::write1Byte(uint8_t id, uint16_t reg, uint8_t data) {
	packetHandler->write1ByteTxRx(portHandler, id, reg, data);
};

void STEMLab_SDK::write1Byte(uint8_t id, uint16_t reg, uint8_t data, float protocol) {
	if (protocol == 2.0){
		packetHandler2P->write1ByteTxRx(portHandler, id, reg, data);
	}
	else{
		packetHandler1P->write1ByteTxRx(portHandler, id, reg, data);
	}
};

void STEMLab_SDK::write2Byte(uint8_t id, uint16_t reg, uint16_t data) {
	packetHandler->write2ByteTxRx(portHandler, id, reg, data);
};

void STEMLab_SDK::write2Byte(uint8_t id, uint16_t reg, uint16_t data, float protocol) {
	if (protocol == 2.0){
		packetHandler2P->write2ByteTxRx(portHandler, id, reg, data);
	}
	else{
		packetHandler1P->write2ByteTxRx(portHandler, id, reg, data);
	}
};

void STEMLab_SDK::write4Byte(uint8_t id, uint16_t reg, uint32_t data) {
	packetHandler->write4ByteTxRx(portHandler, id, reg, data);
};

void STEMLab_SDK::write4Byte(uint8_t id, uint16_t reg, uint32_t data, float protocol) {
	if (protocol == 2.0){
		packetHandler2P->write4ByteTxRx(portHandler, id, reg, data);
	}
	else{
		packetHandler1P->write4ByteTxRx(portHandler, id, reg, data);
	}
};

void STEMLab_SDK::torqueOn(uint8_t id) {
	write1Byte(id, 64, 1);
};

void STEMLab_SDK::torqueOff(uint8_t id) {
	write1Byte(id, 64, 0);
};

void STEMLab_SDK::setPositionMode(uint8_t id) {
	torqueOff(id);
	delay(150);
	write1Byte(id, 11, 3);
	delay(50);
	torqueOn(id);
};

void STEMLab_SDK::setPositionMode(uint8_t id, uint32_t velocity, uint32_t acceleration) {
	torqueOff(id);
	delay(150);
	write4Byte(id, 108, acceleration);
	delay(50);
	write4Byte(id, 112, velocity);
	delay(50);
	write1Byte(id, 11, 3);
	delay(50);
	torqueOn(id);
};

void STEMLab_SDK::setPositionMode(uint8_t id, int velocity, int acceleration) {
	torqueOff(id);
	delay(150);
	write4Byte(id, 108, (uint32_t)acceleration);
	delay(50);
	write4Byte(id, 112, (uint32_t)velocity);
	delay(50);
	write1Byte(id, 11, 3);
	delay(50);
	torqueOn(id);
};

void STEMLab_SDK::setVelocityMode(uint8_t id) {
	torqueOff(id);
	delay(150);
	write1Byte(id, 11, 1);
	delay(50);
	torqueOn(id);
};

void STEMLab_SDK::setVelocityMode(uint8_t id, uint32_t velocity, uint32_t acceleration) {
	torqueOff(id);
	delay(150);
	write4Byte(id, 108, acceleration);
	delay(50);
	write4Byte(id, 112, velocity);
	delay(50);
	write1Byte(id, 11, 1);
	delay(50);
	torqueOn(id);
};

void STEMLab_SDK::setVelocityMode(uint8_t id, int velocity, int acceleration) {
	torqueOff(id);
	delay(150);
	write4Byte(id, 108, (uint32_t)acceleration);
	delay(50);
	write4Byte(id, 112, (uint32_t)velocity);
	delay(50);
	write1Byte(id, 11, 1);
	delay(50);
	torqueOn(id);
};

void STEMLab_SDK::setPostionPID(uint8_t id, uint16_t D_GAIN, uint16_t I_GAIN, uint16_t P_GAIN) {
	write2Byte(id, 80, D_GAIN);
	write2Byte(id, 82, I_GAIN);
	write2Byte(id, 84, P_GAIN);
};

void STEMLab_SDK::setVelocityPID(uint8_t id, uint16_t I_GAIN, uint16_t P_GAIN) {
	write2Byte(id, 76, I_GAIN);
	write2Byte(id, 78, P_GAIN);
};

void STEMLab_SDK::setGoalPosition(uint8_t id, int position) {
	write4Byte(id, 116, (uint32_t)position);
};

void STEMLab_SDK::setGoalPosition(uint8_t id, uint32_t position) {
	write4Byte(id, 116, position);
};

void STEMLab_SDK::setGoalPosition(uint8_t id, float radian) {
	write4Byte(id, 116, (uint32_t)map(radian, 0, 6.28, 0, 16383));
};

void STEMLab_SDK::setGoalVelocity(uint8_t id, int speed) {
	write4Byte(id, 104, (uint32_t)speed);
};

void STEMLab_SDK::setGoalVelocity(uint8_t id, uint32_t speed) {
	write4Byte(id, 104, speed);
};

void STEMLab_SDK::setGoalVelocity(uint8_t id, float radian) {
	write4Byte(id, 104, (uint32_t)map(radian, 0, 6.28, 0, 1023));
};

uint32_t STEMLab_SDK::getPresentPosition(uint8_t id) {
	return read4Byte(id, 132);
};

float STEMLab_SDK::getPresentPositionRad(uint8_t id) {
	float normalized = ((float)getPresentPosition(id) / 16383.0) * 6.28;
	return normalized;
};

int32_t STEMLab_SDK::getPresentVelocity(uint8_t id) {
	return (int32_t)read4Byte(id, 128);
};

float STEMLab_SDK::getPresentVelocityRad(uint8_t id) {
	float normalized = ((float)getPresentVelocity(id) / 1023.0) * 6.28;
	return normalized;
};

void STEMLab_SDK::readBlobs(uint8_t camera_id, uint8_t blob_count) {

	uint8_t count = blob_count > 8 ? 8 : blob_count;
	const int blobs_per_block_n = 3;
	if (count == 0) count = 1;
		
	for (uint8_t i = 0; i < count; i++) {
		uint8_t resp[64], idx = 5;

		if (!(i % blobs_per_block_n))
		{
			idx = 0;
			for (uint8_t j = 0; j < 48; j++) resp[j] = read1Byte(camera_id, (16 + j + (16 * i)));
		}

		if (resp[idx] == 0xFF) {
			resetBlobStruct(blob_count);
			return;
		}

		blob[i].type = resp[idx++];
		blob[i].dummy = resp[idx++];
		blob[i].cx = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].cy = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].area = (uint32_t)((((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8))) * 4;
		idx += 2;
		blob[i].left = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].right = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].top = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].bottom = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
	}
};

void STEMLab_SDK::resetBlobStruct(uint8_t blob_count) {
	for (uint8_t i = 0; i < blob_count; i++) {
		blob[i].type = 0;
		blob[i].dummy = 0;
		blob[i].cx = 0;
		blob[i].cy = 0;
		blob[i].area = 0;
		blob[i].left = 0;
		blob[i].right = 0;
		blob[i].top = 0;
		blob[i].bottom = 0;
	}
}

uint16_t STEMLab_SDK::getPotData(uint8_t id) {
	if (this->protocol == 2.0){
		return read2Byte(id, 26, 1.0);
	}
	return read2Byte(id, 26);
};

uint8_t STEMLab_SDK::getButtonData(uint8_t id) {
	if (this->protocol == 2.0){
		return read1Byte(id, 27, 1.0);
	}
	return read1Byte(id, 27);
};

uint8_t STEMLab_SDK::getLineData(uint8_t id) {
	if (this->protocol == 2.0){
		return read1Byte(id, 27, 1.0);
	}
	return read1Byte(id, 27);
};

uint8_t STEMLab_SDK::getSoundLevel(uint8_t id) {
	if (this->protocol == 2.0){
		return read1Byte(id, 26, 1.0);
	}
	return read1Byte(id, 26);
};

uint8_t STEMLab_SDK::getClapsCount(uint8_t id) {
	if (this->protocol == 2.0){
		return read1Byte(id, 27, 1.0);
	}
	return read1Byte(id, 27);
};

uint16_t STEMLab_SDK::getLastSoundDetectionTime(uint8_t id) {
	if (this->protocol == 2.0){
		return read2Byte(id, 28, 1.0);
	}
	return read2Byte(id, 28);
};

void STEMLab_SDK::setSoundThreshold(uint8_t id, uint8_t threshold) {
	if (this->protocol == 2.0){
		write1Byte(id, 30, threshold, 1.0);
	}
	write1Byte(id, 30, threshold);
};

uint16_t STEMLab_SDK::getDistance(uint8_t id) {
	uint8_t lVal = 0, hVal = 0;
	uint16_t val;
	if (this->protocol == 2.0){
		write1Byte(id, 25, 1, 1.0);
		delay(150);

		lVal = read1Byte(id, 26, 1.0);
		hVal = read1Byte(id, 27, 1.0);
		val = lVal * 256 + hVal;

		return val;
	}

	write1Byte(id, 25, 1);
	delay(150);

	lVal = read1Byte(id, 26);
	hVal = read1Byte(id, 27);
	val = lVal * 256 + hVal;

	return val;
};

uint16_t STEMLab_SDK::getDistance(uint8_t id, uint16_t time) {
	uint8_t lVal = 0, hVal = 0;
	uint16_t val;

	if (this->protocol == 2.0){
		write1Byte(id, 25, 1, 1.0);
		delay(time);

		lVal = read1Byte(id, 26, 1.0);
		hVal = read1Byte(id, 27, 1.0);
		val = lVal * 256 + hVal;

		return val;
	}

	write1Byte(id, 25, 1);
	delay(time);
	
	lVal = read1Byte(id, 26);
	hVal = read1Byte(id, 27);
	val = lVal * 256 + hVal;

	return val;
};

void STEMLab_SDK::findDyns(uint8_t min_id, uint8_t max_id) {
	int bauds[3] = { 57600, 115200, 1000000 };
	uint8_t minId = min_id, maxId = max_id;
	uint8_t currentId = -1;

	uint16_t getModel = -1;
	for (float q = 1.0; q < 3.0; q++) {
		changeProtocolOnPort(q);
		for (uint8_t j = 0; j < 3; j++) {
			changeBaudrateOnPort(bauds[j]);
			for (uint8_t w = minId; w < maxId; w++) {
				getModel = read2Byte(w, 0);
				if (getModel != 0) {
					if (getModel > 100) {
						currentId = read1Byte(w, 7);
					}
					else {
						currentId = read1Byte(w, 3);
					}
					writeName(getModel, currentId, bauds[j], q);
				}
			}
		}
	}
	Serial.println("End of search");
};

void STEMLab_SDK::writeName(uint16_t model_number, uint8_t id, int baud, float protocol) {
	bool isItServo = false;
	uint8_t newId = -1;
	String newValue = "", doesNeedChange = "", name = "";
	switch (model_number) {
		case 3:
			name = "AR_BUTTON";
			break;
		case 9:
			name = "AR_LED";
			break;
		case 10:
			name = "AR_LINE"; 
			break;
		case 12:
			name = "AR_SOUND";
			break;
		case 18:
			name = "AR_NOISE";
			break;
		case 19:
			name = "AR_POT"; 
			break;
		case 21:
			name = "AR_RGB"; 
			break;
		case 34:
		case 42:
			name = "AR_DISTANCE";
			break;
		case 1060:
			name = "XL430_W250_T";
			isItServo = true;
			break;
		case 1061:
			name = "AR_S430_01";
			isItServo = true;
			break;
		default:
			name = "";
			break;
	}
	Serial.println("Found " + name + " with id " + String(id) + " on baudrate : " + String(baud) + " protocol : " + String(protocol));
	Serial.println("Do you want to change ID? Y/N");

	while (true) {
		doesNeedChange = Serial.readStringUntil('\n');
		if (doesNeedChange.length() > 0) {
			if (doesNeedChange[0] == 'Y') {
				Serial.println("Write new ID: ");
				while (true) {
					newValue = Serial.readStringUntil('\n');
					if (newValue.length() > 0) {
						newId = (byte)newValue.toInt();
						Serial.println("new id: " + newValue);
						if (!isItServo) {
							write1Byte(id, 3, newId);
						}
						else {
							write1Byte(id, 7, newId);
						}
						return;
					}
				}
			}
			else {
				return;
			}
		}
	}
};