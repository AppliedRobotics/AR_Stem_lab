#include "MAG_IMU.h"
#define BAUDRATE 1000000 // Скорость обмена данными устройства
#define PROTOCOL 1.0   // Протокол устройства
#define IMU_ID 16    // ID IMU устройства

MAG_IMU imu(BAUDRATE, PROTOCOL);

void setup() {
  Serial.begin(115200);
  imu.init(); // Инициализируем работу библиотеки
}

void loop() {
  // Обновляем данные с IMU
  imu.scan(IMU_ID);
  
  // Получаем углы ориентации
  float roll = imu.getRoll();
  float pitch = imu.getPitch();
  float yaw = imu.getYaw();
  
  // Получаем данные акселерометра
  short accX = imu.getAccX();
  short accY = imu.getAccY();
  short accZ = imu.getAccZ();
  
  // Получаем данные гироскопа
  short gyrX = imu.getGyrX();
  short gyrY = imu.getGyrY();
  short gyrZ = imu.getGyrZ();
  
  // Выводим данные в Serial Monitor
  Serial.print("Roll: "); Serial.print(roll);
  Serial.print(" Pitch: "); Serial.print(pitch);
  Serial.print(" Yaw: "); Serial.println(yaw);
  
  Serial.print("Acc: ");
  Serial.print(accX); Serial.print(", ");
  Serial.print(accY); Serial.print(", ");
  Serial.println(accZ);
  
  Serial.print("Gyr: ");
  Serial.print(gyrX); Serial.print(", ");
  Serial.print(gyrY); Serial.print(", ");
  Serial.println(gyrZ);
  
  // Задержка для стабилизации частоты обновления
  delay(100); 
}