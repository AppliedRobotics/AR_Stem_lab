#include "DXL_IMU_module.h"
#include "madgwickFilter.h"
#include <string>

#define acc_resolution 0.48828125f

MAG_IMU::MAG_IMU(int newBaudrate, float newProtocol) {
    baudrate = newBaudrate;
    protocol = newProtocol;
    imuProtocol = newProtocol; // по умолчанию тот же протокол

    // Инициализация полей
    roll = 0;
    pitch = 0;
    yaw = 0;
    val_ACC_X = 0;
    val_ACC_Y = 0;
    val_ACC_Z = 0;
    val_GYR_X = 0;
    val_GYR_Y = 0;
    val_GYR_Z = 0;
};

void MAG_IMU::init() {
    portHandler = dynamixel::PortHandler::getPortHandler("3");
    // packetHandler = dynamixel::PacketHandler::getPacketHandler(protocol);
    packetHandler1P = dynamixel::PacketHandler::getPacketHandler(1.0);
    packetHandler2P = dynamixel::PacketHandler::getPacketHandler(2.0);
    // Выбираем обработчик по умолчанию
    if (imuProtocol == 2.0)
        packetHandler = packetHandler2P;
    else
        packetHandler = packetHandler1P;
    portHandler->openPort();
    portHandler->setBaudRate(baudrate);
};

uint8_t MAG_IMU::read1ByteProtocol(uint8_t id, uint16_t reg, float protocol) {
    uint8_t data = 0;
    if (protocol == 2.0) {
        packetHandler2P->read1ByteTxRx(portHandler, id, reg, &data);
    } else {
        packetHandler1P->read1ByteTxRx(portHandler, id, reg, &data);
    }
    return data;
}

uint16_t MAG_IMU::read2ByteProtocol(uint8_t id, uint16_t reg, float protocol) {
    uint16_t data = 0;
    if (protocol == 2.0) {
        packetHandler2P->read2ByteTxRx(portHandler, id, reg, &data);
    } else {
        packetHandler1P->read2ByteTxRx(portHandler, id, reg, &data);
    }
    return data;
}

void MAG_IMU::setImuProtocol(float protocol) {
    imuProtocol = protocol;
    if (protocol == 2.0)
        packetHandler = packetHandler2P;
    else
        packetHandler = packetHandler1P;
}

void MAG_IMU::scan(uint8_t id) {
    scan(id, imuProtocol); // вызываем версию с протоколом
}

void MAG_IMU::scan(uint8_t id, float protocol) //
{   
    uint8_t data[26]; // Буфер для чтения 26 байт данных
    uint8_t dxl_error = 0;
    int dxl_comm_result;

    // Читаем блок данных (26 байт начиная с адреса 24)
    // dxl_comm_result = packetHandler->readTxRx(portHandler, id, 24, 26, data, &dxl_error);
    
    // Используем указанный протокол
    if (protocol == 2.0) {
        dxl_comm_result = packetHandler2P->readTxRx(portHandler, id, 24, 26, data, &dxl_error);
    } else {
        dxl_comm_result = packetHandler1P->readTxRx(portHandler, id, 24, 26, data, &dxl_error);
    }

    if (dxl_comm_result == COMM_SUCCESS) {
        /* Разбор данных акселерометра (Little-Endian) */
        int16_t raw_ACC_X = (int16_t)(data[1] << 8) | data[0];
        int16_t raw_ACC_Y = (int16_t)(data[3] << 8) | data[2];
        int16_t raw_ACC_Z = (int16_t)(data[5] << 8) | data[4];
        
        val_ACC_X = (int16_t)((float)raw_ACC_X * acc_resolution);
        val_ACC_Y = (int16_t)((float)raw_ACC_Y * acc_resolution);
        val_ACC_Z = (int16_t)((float)raw_ACC_Z * acc_resolution);

        /* Разбор данных гироскопа (Little-Endian) */
        val_GYR_X = (int16_t)(data[7] << 8) | data[6];
        val_GYR_Y = (int16_t)(data[9] << 8) | data[8];
        val_GYR_Z = (int16_t)(data[11] << 8) | data[10];

        /* Разбор данных угла (Little-Endian) */
        int16_t val_IMU_DEGREE_INT = (int16_t)(data[23] << 8) | data[22];
        int8_t IMU_DEGREE_FRAC_INT = (int8_t)data[24]; // Дробная часть (1 байт)

        // Нормализация угла в диапазон [0, 360)
        val_IMU_DEGREE_INT %= 360;
        if (val_IMU_DEGREE_INT < 0) {
            val_IMU_DEGREE_INT += 360;
            IMU_DEGREE_FRAC_INT = -IMU_DEGREE_FRAC_INT; // Корректировка знака
        }

        // Применение фильтра Madgwick
        imu_filter(
            (float)val_ACC_X, 
            (float)val_ACC_Y, 
            (float)val_ACC_Z, 
            (float)val_GYR_X  * PI / 180 / 100, 
            (float)val_GYR_Y  * PI / 180 / 100, 
            (float)val_GYR_Z  * PI / 180 / 100
        );
        
        // Расчет углов Эйлера
        eulerAngles(q_est, &roll, &pitch);
        
        // Расчет рысканья с учетом дробной части
        yaw = (float)val_IMU_DEGREE_INT + (abs(IMU_DEGREE_FRAC_INT) / 10.0f);
    }                   
}
