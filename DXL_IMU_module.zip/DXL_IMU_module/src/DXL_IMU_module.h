#include <Arduino.h>
#include <DynamixelSDK.h>

class MAG_IMU {
public:
    MAG_IMU(int baudrate, float protocol);
    void init();
    void scan(uint8_t id);
    void scan(uint8_t id, float protocol);  // новый метод с указанием протокола

    // Новые методы для работы с протоколами
    void setImuProtocol(float protocol);
    uint8_t read1ByteProtocol(uint8_t id, uint16_t reg, float protocol);
    uint16_t read2ByteProtocol(uint8_t id, uint16_t reg, float protocol);
    
    // Геттеры
    float getRoll() const { return roll; }
    float getPitch() const { return pitch; }
    float getYaw() const { return yaw; }

    // Геттеры
    short getAccX() const { return val_ACC_X; }
    short getAccY() const { return val_ACC_Y; }
    short getAccZ() const { return val_ACC_Z; }

    // Геттеры
    short getGyrX() const { return val_GYR_X; }
    short getGyrY() const { return val_GYR_Y; }
    short getGyrZ() const { return val_GYR_Z; }

protected:
    float protocol;
    int baudrate;
    // dynamixel::PortHandler* portHandler;
    // dynamixel::PacketHandler* packetHandler;
    float imuProtocol;        // протокол для IMU (например, 1.0)
    dynamixel::PortHandler *portHandler;
    dynamixel::PacketHandler *packetHandler;
    dynamixel::PacketHandler *packetHandler1P;
    dynamixel::PacketHandler *packetHandler2P;

private:
    // Данные IMU
    float roll;
    float pitch;
    float yaw;
    short val_ACC_X;
    short val_ACC_Y;
    short val_ACC_Z;
    short val_GYR_X;
    short val_GYR_Y;
    short val_GYR_Z;
};
