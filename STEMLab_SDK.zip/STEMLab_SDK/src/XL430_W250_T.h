#pragma once

#include "STEMLab_Servos.h"

class XL430_W250_T : public DynamixelServo {
public:
    using DynamixelServo::DynamixelServo;

    void torqueOn() override;
    void torqueOff() override;

    void setPositionMode() override;
    void setPositionMode(uint32_t velocity) override;
    void setPositionMode(uint32_t velocity, uint32_t acceleration) override;
    void setPositionMode(int velocity, int acceleration) override;

    void setVelocityMode() override;
    void setVelocityMode(uint32_t velocity, uint32_t acceleration) override;
    void setVelocityMode(int velocity, int acceleration) override;

    void setPositionPID(uint16_t D_GAIN, uint16_t I_GAIN, uint16_t P_GAIN) override;
    void setVelocityPID(uint16_t I_GAIN, uint16_t P_GAIN) override;

    void setGoalPosition(int position) override;
    void setGoalPosition(uint32_t position) override;
    void setGoalPosition(float radian) override;

    void setGoalVelocity(int speed) override;
    void setGoalVelocity(uint32_t speed) override;
    void setGoalVelocity(float radian) override;

    uint32_t getPresentPosition() override;
    float getPresentPositionRad() override;
    int32_t getPresentVelocity() override;
    float getPresentVelocityRad() override;
};