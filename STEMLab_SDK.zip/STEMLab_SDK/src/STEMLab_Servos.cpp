#include "STEMLab_Servos.h"
#include "STEMLab_SDK.h"

DynamixelServo::DynamixelServo(STEMLab_SDK& sdk, uint8_t id)
    : sdk(sdk), id(id) {
}

void DynamixelServo::torqueOn()  {}

void DynamixelServo::torqueOff() {}

void DynamixelServo::setPositionMode() {}

void DynamixelServo::setPositionMode(uint32_t velocity){}

void DynamixelServo::setPositionMode(uint32_t velocity, uint32_t acceleration) {}

void DynamixelServo::setPositionMode(int velocity, int acceleration) {}

void DynamixelServo::setVelocityMode() {}

void DynamixelServo::setVelocityMode(uint32_t velocity, uint32_t acceleration) {}

void DynamixelServo::setVelocityMode(int velocity, int acceleration){}

void DynamixelServo::setPositionPID(uint16_t D_GAIN, uint16_t I_GAIN, uint16_t P_GAIN) {}

void DynamixelServo::setVelocityPID(uint16_t I_GAIN, uint16_t P_GAIN) {}

void DynamixelServo::setGoalPosition(int position) {}

void DynamixelServo::setGoalPosition(uint32_t position) {}

void DynamixelServo::setGoalPosition(float radian) {}

void DynamixelServo::setGoalVelocity(int speed) {}

void DynamixelServo::setGoalVelocity(uint32_t speed) {}

void DynamixelServo::setGoalVelocity(float radian) {}

uint32_t DynamixelServo::getPresentPosition() {}

float DynamixelServo::getPresentPositionRad() {}

int32_t DynamixelServo::getPresentVelocity() {}

float DynamixelServo::getPresentVelocityRad() {}