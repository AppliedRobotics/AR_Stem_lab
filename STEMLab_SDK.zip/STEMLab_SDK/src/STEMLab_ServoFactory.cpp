#include "STEMLab_ServoFactory.h"
#include "XL430_W250_T.h"
#include "AX_12A.h"

DynamixelServo* ServoFactory::create(
    STEMLab_SDK& sdk,
    uint8_t id,
    uint16_t modelNumber
) {
    switch (modelNumber) {
        case 1060:
        case 1061:
            return new XL430_W250_T(sdk, id);
        case 12:
            return new AX_12A(sdk, id);
        default:
            return nullptr;
    }
}