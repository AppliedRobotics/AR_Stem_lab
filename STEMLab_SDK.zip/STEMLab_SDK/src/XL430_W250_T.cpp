#include "Arduino.h"
#include "XL430_W250_T.h"
#include "STEMLab_SDK.h"

void XL430_W250_T::torqueOn()  {
    sdk.write1Byte(id, 64, 1);
}

void XL430_W250_T::torqueOff() {
    sdk.write1Byte(id, 64, 0);
}

void XL430_W250_T::setPositionMode() {
    torqueOff();
    delay(150);
    sdk.write1Byte(id, 11, 3);
    delay(50);
    torqueOn();
}

void XL430_W250_T::setPositionMode(uint32_t velocity){
    torqueOff();
    delay(150);
    sdk.write1Byte(id, 11, 3);
    delay(50);
    sdk.write4Byte(id, 112, velocity);
    delay(50);
    torqueOn();
}

void XL430_W250_T::setPositionMode(uint32_t velocity, uint32_t acceleration) {
    torqueOff();
    delay(150);
    sdk.write4Byte(id, 108, acceleration);
    delay(50);
    sdk.write4Byte(id, 112, velocity);
    delay(50);
    sdk.write1Byte(id, 11, 3);
    delay(50);
    torqueOn();
}

void XL430_W250_T::setPositionMode(int velocity, int acceleration) {
    torqueOff();
    delay(150);
    sdk.write4Byte(id, 108, (uint32_t)acceleration);
    delay(50);
    sdk.write4Byte(id, 112, (uint32_t)velocity);
    delay(50);
    sdk.write1Byte(id, 11, 3);
    delay(50);
    torqueOn();
}

void XL430_W250_T::setVelocityMode() {
    torqueOff();
    delay(150);
    sdk.write1Byte(id, 11, 1);
    delay(50);
    torqueOn();
}

void XL430_W250_T::setVelocityMode(uint32_t velocity, uint32_t acceleration) {
    torqueOff();
    delay(150);
    sdk.write4Byte(id, 108, acceleration);
    delay(50);
    sdk.write4Byte(id, 112, velocity);
    delay(50);
    sdk.write1Byte(id, 11, 1);
    delay(50);
    torqueOn();
}

void XL430_W250_T::setVelocityMode(int velocity, int acceleration){
    torqueOff();
    delay(150);
    sdk.write4Byte(id, 108, (uint32_t)acceleration);
    delay(50);
    sdk.write4Byte(id, 112, (uint32_t)velocity);
    delay(50);
    sdk.write1Byte(id, 11, 1);
    delay(50);
    torqueOn();
}

void XL430_W250_T::setPositionPID(uint16_t D_GAIN, uint16_t I_GAIN, uint16_t P_GAIN) {
    sdk.write2Byte(id, 80, D_GAIN);
    sdk.write2Byte(id, 82, I_GAIN);
    sdk.write2Byte(id, 84, P_GAIN);
}

void XL430_W250_T::setVelocityPID(uint16_t I_GAIN, uint16_t P_GAIN) {
    sdk.write2Byte(id, 76, I_GAIN);
    sdk.write2Byte(id, 78, P_GAIN);
}

void XL430_W250_T::setGoalPosition(int position) {
    sdk.write4Byte(id, 116, (uint32_t)position);
}

void XL430_W250_T::setGoalPosition(uint32_t position) {
    sdk.write4Byte(id, 116, position);
}

void XL430_W250_T::setGoalPosition(float radian) {
    sdk.write4Byte(id, 116, (uint32_t)map(radian, 0, 6.28, 0, 16383));
}

void XL430_W250_T::setGoalVelocity(int speed) {
    sdk.write4Byte(id, 104, (uint32_t)speed);
}

void XL430_W250_T::setGoalVelocity(uint32_t speed) {
    sdk.write4Byte(id, 104, speed);
}

void XL430_W250_T::setGoalVelocity(float radian) {
    sdk.write4Byte(id, 104, (uint32_t)map(radian, 0, 6.28, 0, 1023));
}

uint32_t XL430_W250_T::getPresentPosition() {
    return sdk.read4Byte(id, 132);
}

float XL430_W250_T::getPresentPositionRad() {
    float normalized = ((float)getPresentPosition() / 16383.0) * 6.28;
    return normalized;
}

int32_t XL430_W250_T::getPresentVelocity() {
    return (int32_t)sdk.read4Byte(id, 128);
}

float XL430_W250_T::getPresentVelocityRad() {
    float normalized = ((float)getPresentVelocity() / 1023.0) * 6.28;
    return normalized;
}