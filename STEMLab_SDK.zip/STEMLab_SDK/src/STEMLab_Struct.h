#include <Arduino.h>

struct TrackingCamBlobInfo_t
{
	uint8_t type;
	uint8_t dummy;
	uint16_t cx;
	uint16_t cy;
	uint32_t area;
	uint16_t left;
	uint16_t right;
	uint16_t top;
	uint16_t bottom;
};

struct TrackingCamArucoInfo_t
{
	uint8_t id;
	uint16_t cx;
	uint16_t cy;
};