#include <Arduino.h>
#include <DynamixelSDK.h>
#include <STEMLab_Struct.h>
#include "STEMLab_Servos.h"

class STEMLab_SDK {
	public:
		STEMLab_SDK(int baudrate, float protocol);
		void init();
		void changeBaudrateOnPort(int baudrate);
		void changeBaudrate(uint8_t id, uint16_t reg, uint32_t baudrate);
		void changeId(uint8_t id, uint16_t idReg, uint8_t newId);
		void changeProtocolOnPort(float protocol);
		void changeProtocol(uint8_t id, float protocol);
		uint8_t read1Byte(uint8_t id, uint16_t reg);
		uint8_t read1Byte(uint8_t id, uint16_t reg, float protocol);
		uint16_t read2Byte(uint8_t id, uint16_t reg);
		uint16_t read2Byte(uint8_t id, uint16_t reg, float protocol);
		uint32_t read4Byte(uint8_t id, uint16_t reg);
		uint32_t read4Byte(uint8_t id, uint16_t reg, float protocol);
		void write1Byte(uint8_t id, uint16_t reg, uint8_t data);
		void write1Byte(uint8_t id, uint16_t reg, uint8_t data, float protocol);
		void write2Byte(uint8_t id, uint16_t reg, uint16_t data);
		void write2Byte(uint8_t id, uint16_t reg, uint16_t data, float protocol);
		void write4Byte(uint8_t id, uint16_t reg, uint32_t data);
		void write4Byte(uint8_t id, uint16_t reg, uint32_t data, float protocol);
		void findDyns(uint8_t min_id, uint8_t max_id);
		//camera methods
		TrackingCamBlobInfo_t blob[8];
		TrackingCamArucoInfo_t aruco[8];
		void readBlobs(uint8_t camera_id, uint8_t blob_count);
		void readArucos(uint8_t camera_id, uint8_t aruco_count);
		//servo methods
		void torque(uint8_t id, uint16_t reg, uint8_t value);
		void torqueOn(uint8_t id);
		void torqueOff(uint8_t id);
		void setPositionMode(uint8_t id, int om_reg, bool change_cw_reg, uint16_t cw_reg, uint16_t ccw_reg, uint8_t w_reg_len, int cw_val, int ccw_val);
		void setPositionMode(uint8_t id);
		void setPositionMode(uint8_t id, uint32_t velocity);
		void setPositionMode(uint8_t id, uint32_t velocity, uint32_t acceleration);
		void setPositionMode(uint8_t id, int velocity, int acceleration);
		void setVelocityMode(uint8_t id, int om_reg, bool change_cw_reg, uint16_t cw_reg, uint16_t ccw_reg, uint8_t w_reg_len, int cw_val, int ccw_val);
		void setVelocityMode(uint8_t id);
		void setVelocityMode(uint8_t id, uint32_t velocity, uint32_t acceleration);
		void setVelocityMode(uint8_t id, int velocity, int acceleration);
		void setPositionPID(uint8_t id, uint16_t D_GAIN, uint16_t I_GAIN, uint16_t P_GAIN);
		void setVelocityPID(uint8_t id, uint16_t I_GAIN, uint16_t P_GAIN);
		void setGoalPosition(uint8_t id, uint32_t position);
		void setGoalPosition(uint8_t id, int position);
		void setGoalPosition(uint8_t id, float radian);
		void setGoalVelocity(uint8_t id, uint32_t speed);
		void setGoalVelocity(uint8_t id, int speed);
		void setGoalVelocity(uint8_t id, float radian);
		uint32_t getPresentPosition(uint8_t id);
		float getPresentPositionRad(uint8_t id);
		int32_t getPresentVelocity(uint8_t id);
		float getPresentVelocityRad(uint8_t id);
		//periphery methods
		uint16_t getPotData(uint8_t id);//pot
		uint8_t getButtonData(uint8_t id);//button
		uint8_t getLineData(uint8_t id);//line
		uint8_t getSoundLevel(uint8_t id);//sound
		uint8_t getClapsCount(uint8_t id);//sound
		uint16_t getLastSoundDetectionTime(uint8_t id);//sound
		void setRGB(uint8_t id, uint8_t r, uint8_t g, uint8_t b);//rgb
		void setSoundThreshold(uint8_t id, uint8_t threshold);//sound
		uint16_t getDistance(uint8_t id);//dist
		uint16_t getDistance(uint8_t id, uint16_t time);//dist

	protected:
		ServoEntry servos[253];
		uint8_t servoCount = 0;
		bool servoExists(uint8_t id);
		bool addServo(int key, DynamixelServo* value);
		DynamixelServo* getServo(int key);
		void resetBlobStruct(uint8_t blob_count); 
		float protocol;
		int baudrate;
		dynamixel::PortHandler* portHandler;
		dynamixel::PacketHandler* packetHandler;
		dynamixel::PacketHandler* packetHandler1P;
		dynamixel::PacketHandler* packetHandler2P;
		void writeName(uint16_t model_number, uint8_t id, int baud, float protocol);
};