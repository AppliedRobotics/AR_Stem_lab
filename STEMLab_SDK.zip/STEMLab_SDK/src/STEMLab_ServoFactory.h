#pragma once

#include "STEMLab_Servos.h"

class STEMLab_SDK;

class ServoFactory {
public:
    static DynamixelServo* create(
        STEMLab_SDK& sdk,
        uint8_t id,
        uint16_t modelNumber
    );
};