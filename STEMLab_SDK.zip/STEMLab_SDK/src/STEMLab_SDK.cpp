#include "STEMLab_SDK.h"
#include "STEMLab_ServoFactory.h"
#include <string>

STEMLab_SDK::STEMLab_SDK(int newBaudrate, float newProtocol) {
	baudrate = newBaudrate;
	protocol = newProtocol;
};

void STEMLab_SDK::init() {
	portHandler = dynamixel::PortHandler::getPortHandler("3");
	packetHandler = dynamixel::PacketHandler::getPacketHandler(protocol);
	packetHandler1P = dynamixel::PacketHandler::getPacketHandler(1.0);
	packetHandler2P = dynamixel::PacketHandler::getPacketHandler(2.0);
	portHandler->openPort();
	portHandler->setBaudRate(baudrate);
};

void STEMLab_SDK::changeBaudrateOnPort(int newBaudrate) {
	baudrate = newBaudrate;
	portHandler->setBaudRate(newBaudrate);
};

void STEMLab_SDK::changeBaudrate(uint8_t id, uint16_t reg, uint32_t baudrate) {
	if (reg == 8) {
		switch (baudrate) {
			case 57600:
				write1Byte(id, reg, 1);
				break;
			case 115200:
				write1Byte(id, reg, 2);
				break;
			case 1000000:
				write1Byte(id, reg, 3);
				break;
		}
	}
	else if (reg == 4) {
		switch (baudrate) {
			case 57600:
				write1Byte(id, reg, 34);
				break;
			case 115200:
				write1Byte(id, reg, 16);
				break;
			case 1000000:
				write1Byte(id, reg, 1);
				break;
		}
	}
}

void STEMLab_SDK::changeId(uint8_t id, uint16_t idReg, uint8_t newId) {
	write1Byte(id, idReg, newId);
};

void STEMLab_SDK::changeProtocolOnPort(float newProtocol) {
	packetHandler = dynamixel::PacketHandler::getPacketHandler(newProtocol);
	protocol = newProtocol;
};

void STEMLab_SDK::changeProtocol(uint8_t newId, float newProtocol) {
	write1Byte(newId, 13, newProtocol);
}

uint8_t STEMLab_SDK::read1Byte(uint8_t id, uint16_t reg) {
	uint8_t data = 0;
	packetHandler->read1ByteTxRx(portHandler, id, reg, (uint8_t*)&data);
	return data;
};

uint8_t STEMLab_SDK::read1Byte(uint8_t id, uint16_t reg, float protocol) {
	uint8_t data = 0;

	if (protocol == 2.0){
		packetHandler2P->read1ByteTxRx(portHandler, id, reg, (uint8_t*)&data);
	}
	else{
		packetHandler1P->read1ByteTxRx(portHandler, id, reg, (uint8_t*)&data);
	}
	
	return data;
};

uint16_t STEMLab_SDK::read2Byte(uint8_t id, uint16_t reg) {
	uint16_t data = 0;
	packetHandler->read2ByteTxRx(portHandler, id, reg, (uint16_t*)&data);
	return data;
};

uint16_t STEMLab_SDK::read2Byte(uint8_t id, uint16_t reg, float protocol) {
	uint16_t data = 0;

	if (protocol == 2.0){
		packetHandler2P->read2ByteTxRx(portHandler, id, reg, (uint16_t*)&data);
	}
	else{
		packetHandler1P->read2ByteTxRx(portHandler, id, reg, (uint16_t*)&data);
	}

	return data;
};

uint32_t STEMLab_SDK::read4Byte(uint8_t id, uint16_t reg) {
	uint32_t data = 0;
	packetHandler->read4ByteTxRx(portHandler, id, reg, (uint32_t*)&data);
	return data;
};

uint32_t STEMLab_SDK::read4Byte(uint8_t id, uint16_t reg, float protocol) {
	uint32_t data = 0;

	if (protocol == 2.0){
		packetHandler2P->read4ByteTxRx(portHandler, id, reg, (uint32_t*)&data);
	}
	else{
		packetHandler1P->read4ByteTxRx(portHandler, id, reg, (uint32_t*)&data);
	}

	return data;
};

void STEMLab_SDK::write1Byte(uint8_t id, uint16_t reg, uint8_t data) {
	packetHandler->write1ByteTxRx(portHandler, id, reg, data);
};

void STEMLab_SDK::write1Byte(uint8_t id, uint16_t reg, uint8_t data, float protocol) {
	if (protocol == 2.0){
		packetHandler2P->write1ByteTxRx(portHandler, id, reg, data);
	}
	else{
		packetHandler1P->write1ByteTxRx(portHandler, id, reg, data);
	}
};

void STEMLab_SDK::write2Byte(uint8_t id, uint16_t reg, uint16_t data) {
	packetHandler->write2ByteTxRx(portHandler, id, reg, data);
};

void STEMLab_SDK::write2Byte(uint8_t id, uint16_t reg, uint16_t data, float protocol) {
	if (protocol == 2.0){
		packetHandler2P->write2ByteTxRx(portHandler, id, reg, data);
	}
	else{
		packetHandler1P->write2ByteTxRx(portHandler, id, reg, data);
	}
};

void STEMLab_SDK::write4Byte(uint8_t id, uint16_t reg, uint32_t data) {
	packetHandler->write4ByteTxRx(portHandler, id, reg, data);
};

void STEMLab_SDK::write4Byte(uint8_t id, uint16_t reg, uint32_t data, float protocol) {
	if (protocol == 2.0){
		packetHandler2P->write4ByteTxRx(portHandler, id, reg, data);
	}
	else{
		packetHandler1P->write4ByteTxRx(portHandler, id, reg, data);
	}
};

bool STEMLab_SDK::addServo(int key, DynamixelServo* servo) {
    if (servo == nullptr) {
        return false;
    }

    for (int i = 0; i < servoCount; i++) {
        if (servos[i].key == key) {
            return false;
        }
    }

    servos[servoCount] = {key, servo};
    servoCount++;

    return true;
}

DynamixelServo* STEMLab_SDK::getServo(int key) {
    for (int i = 0; i < servoCount; i++) {
        if (servos[i].key == key) {
            return servos[i].value;
        }
    }

	uint16_t model_number = read2Byte(key, 0);
	if (model_number == 0) return nullptr;

	DynamixelServo* servo = ServoFactory::create(*this, key, model_number);
	addServo(key, servo);

    return servo;
}

void STEMLab_SDK::torque(uint8_t id, uint16_t reg, uint8_t value){
	write1Byte(id, reg, value);
}

void STEMLab_SDK::torqueOn(uint8_t id) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->torqueOn();
};

void STEMLab_SDK::torqueOff(uint8_t id) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}
	
	servo->torqueOff();
};

void STEMLab_SDK::setPositionMode(uint8_t id, int om_reg, bool change_cw_reg, uint16_t cw_reg, uint16_t ccw_reg, uint8_t w_reg_len, int cw_val, int ccw_val){
	if (om_reg != -1) {
		write1Byte(id, om_reg, 3);
	}

	if (change_cw_reg) {
		if (w_reg_len == 1) {
			write1Byte(id, cw_reg, cw_val);
			write1Byte(id, ccw_reg, ccw_val);
		}
		else if (w_reg_len == 2) {
			write2Byte(id, cw_reg, cw_val);
			write2Byte(id, ccw_reg, ccw_val);
		}
		else if (w_reg_len == 4) {
			write4Byte(id, cw_reg, cw_val);
			write4Byte(id, ccw_reg, ccw_val);
		}
	}
}

void STEMLab_SDK::setPositionMode(uint8_t id) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setPositionMode();
};

void STEMLab_SDK::setPositionMode(uint8_t id, uint32_t velocity){
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setPositionMode(velocity);
}

void STEMLab_SDK::setPositionMode(uint8_t id, uint32_t velocity, uint32_t acceleration) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setPositionMode(velocity, acceleration);
};

void STEMLab_SDK::setPositionMode(uint8_t id, int velocity, int acceleration) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setPositionMode(velocity, acceleration);
};

void STEMLab_SDK::setVelocityMode(uint8_t id, int om_reg, bool change_cw_reg, uint16_t cw_reg, uint16_t ccw_reg, uint8_t w_reg_len, int cw_val, int ccw_val){
	if (om_reg != -1) {
		write1Byte(id, om_reg, 1);
	}

	if (change_cw_reg) {
		if (w_reg_len == 1) {
			write1Byte(id, cw_reg, cw_val);
			write1Byte(id, ccw_reg, ccw_val);
		}
		else if (w_reg_len == 2) {
			write2Byte(id, cw_reg, cw_val);
			write2Byte(id, ccw_reg, ccw_val);
		}
		else if (w_reg_len == 4) {
			write4Byte(id, cw_reg, cw_val);
			write4Byte(id, ccw_reg, ccw_val);
		}
	}
};

void STEMLab_SDK::setVelocityMode(uint8_t id) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setVelocityMode();
};

void STEMLab_SDK::setVelocityMode(uint8_t id, uint32_t velocity, uint32_t acceleration) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setVelocityMode(velocity, acceleration);
};

void STEMLab_SDK::setVelocityMode(uint8_t id, int velocity, int acceleration) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setVelocityMode(velocity, acceleration);
};

void STEMLab_SDK::setPositionPID(uint8_t id, uint16_t D_GAIN, uint16_t I_GAIN, uint16_t P_GAIN) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setPositionPID(D_GAIN, I_GAIN, P_GAIN);
};

void STEMLab_SDK::setVelocityPID(uint8_t id, uint16_t I_GAIN, uint16_t P_GAIN) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setVelocityPID(I_GAIN, P_GAIN);
};

void STEMLab_SDK::setGoalPosition(uint8_t id, int position) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setGoalPosition(position);
};

void STEMLab_SDK::setGoalPosition(uint8_t id, uint32_t position) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setGoalPosition(position);
};

void STEMLab_SDK::setGoalPosition(uint8_t id, float radian) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setGoalPosition(radian);
};

void STEMLab_SDK::setGoalVelocity(uint8_t id, int speed) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setGoalVelocity(speed);
};

void STEMLab_SDK::setGoalVelocity(uint8_t id, uint32_t speed) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setGoalVelocity(speed);
};

void STEMLab_SDK::setGoalVelocity(uint8_t id, float radian) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return;
	}

	servo->setGoalVelocity(radian);
};

uint32_t STEMLab_SDK::getPresentPosition(uint8_t id) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return 0;
	}

	return servo->getPresentPosition();
};

float STEMLab_SDK::getPresentPositionRad(uint8_t id) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return 0;
	}

	return servo->getPresentPositionRad();
};

int32_t STEMLab_SDK::getPresentVelocity(uint8_t id) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return 0;
	}

	return servo->getPresentVelocity();
};

float STEMLab_SDK::getPresentVelocityRad(uint8_t id) {
	DynamixelServo* servo = getServo(id);

	if (servo == nullptr){
		Serial.println("Servo not found");
		return 0;
	}

	return servo->getPresentVelocityRad();
};

void STEMLab_SDK::readBlobs(uint8_t camera_id, uint8_t blob_count) {

	uint8_t count = blob_count > 8 ? 8 : blob_count;
	const int blobs_per_block_n = 3;
	if (count == 0) count = 1;
		
	for (uint8_t i = 0; i < count; i++) {
		uint8_t resp[64], idx = 5;

		if (!(i % blobs_per_block_n))
		{
			idx = 0;
			for (uint8_t j = 0; j < 48; j++) resp[j] = read1Byte(camera_id, (16 + j + (16 * i)));
		}

		if (resp[idx] == 0xFF) {
			resetBlobStruct(blob_count);
			return;
		}

		blob[i].type = resp[idx++];
		blob[i].dummy = resp[idx++];
		blob[i].cx = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].cy = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].area = (uint32_t)((((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8))) * 4;
		idx += 2;
		blob[i].left = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].right = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].top = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
		blob[i].bottom = ((uint16_t)resp[idx]) + (((uint16_t)resp[idx + 1]) << 8);
		idx += 2;
	}
};

void STEMLab_SDK::readArucos(uint8_t camera_id, uint8_t aruco_count){
	uint8_t lines = aruco_count > 8 ? 8 : aruco_count;
	if (lines < 0) lines = 0;
	uint8_t idx = 16;
	uint8_t n = 0;

	for (uint8_t i = 0; i < lines; i++){
		aruco[i].id = read1Byte(camera_id, idx++);
		aruco[i].cx = read2Byte(camera_id, idx); idx += 2;
		aruco[i].cy = read2Byte(camera_id, idx); idx += 2;
	}
};

void STEMLab_SDK::resetBlobStruct(uint8_t blob_count) {
	for (uint8_t i = 0; i < blob_count; i++) {
		blob[i].type = 0;
		blob[i].dummy = 0;
		blob[i].cx = 0;
		blob[i].cy = 0;
		blob[i].area = 0;
		blob[i].left = 0;
		blob[i].right = 0;
		blob[i].top = 0;
		blob[i].bottom = 0;
	}
};

uint16_t STEMLab_SDK::getPotData(uint8_t id) {
	if (this->protocol == 2.0){
		return read2Byte(id, 26, 1.0);
	}
	return read2Byte(id, 26);
};

uint8_t STEMLab_SDK::getButtonData(uint8_t id) {
	if (this->protocol == 2.0){
		return read1Byte(id, 27, 1.0);
	}
	return read1Byte(id, 27);
};

uint8_t STEMLab_SDK::getLineData(uint8_t id) {
	if (this->protocol == 2.0){
		return read1Byte(id, 27, 1.0);
	}
	return read1Byte(id, 27);
};

uint8_t STEMLab_SDK::getSoundLevel(uint8_t id) {
	if (this->protocol == 2.0){
		return read1Byte(id, 26, 1.0);
	}
	return read1Byte(id, 26);
};

uint8_t STEMLab_SDK::getClapsCount(uint8_t id) {
	if (this->protocol == 2.0){
		return read1Byte(id, 27, 1.0);
	}
	return read1Byte(id, 27);
};

uint16_t STEMLab_SDK::getLastSoundDetectionTime(uint8_t id) {
	if (this->protocol == 2.0){
		return read2Byte(id, 28, 1.0);
	}
	return read2Byte(id, 28);
};

void STEMLab_SDK::setRGB(uint8_t id, uint8_t r, uint8_t g, uint8_t b){
	if (this->protocol == 2.0){
		write1Byte(id, 27, r, 1.0);
		write1Byte(id, 26, g, 1.0);
		write1Byte(id, 28, b, 1.0);
		return;
	}

	write1Byte(id, 27, r, 1.0);
	write1Byte(id, 26, g);
	write1Byte(id, 28, b);
}

void STEMLab_SDK::setSoundThreshold(uint8_t id, uint8_t threshold) {
	if (this->protocol == 2.0){
		write1Byte(id, 30, threshold, 1.0);
		return;
	}
	write1Byte(id, 30, threshold);
};

uint16_t STEMLab_SDK::getDistance(uint8_t id) {
	uint8_t lVal = 0, hVal = 0;
	uint16_t val;
	if (this->protocol == 2.0){
		write1Byte(id, 25, 1, 1.0);
		delay(150);

		lVal = read1Byte(id, 26, 1.0);
		hVal = read1Byte(id, 27, 1.0);
		val = lVal * 256 + hVal;

		return val;
	}

	write1Byte(id, 25, 1);
	delay(150);

	lVal = read1Byte(id, 26);
	hVal = read1Byte(id, 27);
	val = lVal * 256 + hVal;

	return val;
};

uint16_t STEMLab_SDK::getDistance(uint8_t id, uint16_t time) {
	uint8_t lVal = 0, hVal = 0;
	uint16_t val;

	if (this->protocol == 2.0){
		write1Byte(id, 25, 1, 1.0);
		delay(time);

		lVal = read1Byte(id, 26, 1.0);
		hVal = read1Byte(id, 27, 1.0);
		val = lVal * 256 + hVal;

		return val;
	}

	write1Byte(id, 25, 1);
	delay(time);
	
	lVal = read1Byte(id, 26);
	hVal = read1Byte(id, 27);
	val = lVal * 256 + hVal;

	return val;
};

void STEMLab_SDK::findDyns(uint8_t min_id, uint8_t max_id) {
	int bauds[3] = { 57600, 115200, 1000000 };
	uint8_t minId = min_id, maxId = max_id;
	uint8_t currentId = -1;

	uint16_t getModel = -1;
	for (float q = 1.0; q < 3.0; q++) {
		changeProtocolOnPort(q);
		for (uint8_t j = 0; j < 3; j++) {
			changeBaudrateOnPort(bauds[j]);
			for (uint8_t w = minId; w < maxId; w++) {
				getModel = read2Byte(w, 0);
				if (getModel != 0) {
					if (getModel > 100) {
						currentId = read1Byte(w, 7);
					}
					else {
						currentId = read1Byte(w, 3);
					}
					writeName(getModel, currentId, bauds[j], q);
				}
			}
		}
	}
	Serial.println("End of search");
};

void STEMLab_SDK::writeName(uint16_t model_number, uint8_t id, int baud, float protocol) {
	bool isItServo = false;
	uint8_t newId = -1;
	String newValue = "", doesNeedChange = "", name = "";
	switch (model_number) {
		case 3:
			name = "AR_BUTTON";
			break;
		case 9:
			name = "AR_LED";
			break;
		case 10:
			name = "AR_LINE"; 
			break;
		case 12:
			name = "AR_SOUND";
			break;
		case 18:
			name = "AR_NOISE";
			break;
		case 19:
			name = "AR_POT"; 
			break;
		case 21:
			name = "AR_RGB"; 
			break;
		case 34:
		case 42:
			name = "AR_DISTANCE";
			break;
		case 1060:
			name = "XL430_W250_T";
			isItServo = true;
			break;
		case 1061:
			name = "AR_S430_01";
			isItServo = true;
			break;
		default:
			name = "";
			break;
	}
	Serial.println("Found " + name + " with id " + String(id) + " on baudrate : " + String(baud) + " protocol : " + String(protocol));
	Serial.println("Do you want to change ID? Y/N");

	while (true) {
		doesNeedChange = Serial.readStringUntil('\n');
		if (doesNeedChange.length() > 0) {
			if (doesNeedChange[0] == 'Y') {
				Serial.println("Write new ID: ");
				while (true) {
					newValue = Serial.readStringUntil('\n');
					if (newValue.length() > 0) {
						newId = (byte)newValue.toInt();
						Serial.println("new id: " + newValue);
						if (!isItServo) {
							write1Byte(id, 3, newId);
						}
						else {
							write1Byte(id, 7, newId);
						}
						return;
					}
				}
			}
			else {
				return;
			}
		}
	}
};