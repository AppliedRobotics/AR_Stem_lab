#include "Arduino.h"
#include "AX_12A.h"
#include "STEMLab_SDK.h"

void AX_12A::torqueOn()  {
    sdk.write1Byte(id, 24, 1);
}

void AX_12A::torqueOff() {
    sdk.write1Byte(id, 24, 0);
}

void AX_12A::setPositionMode() {
    torqueOff();
    delay(150);
    sdk.setPositionMode(id, -1, true, 6, 8, 2, 0, 1023);
    delay(50);
    torqueOn();
}

void AX_12A::setPositionMode(uint32_t velocity){
    torqueOff();
    delay(150);
    sdk.setPositionMode(id, -1, true, 6, 8, 2, 0, 1023);
    sdk.write2Byte(id, 32, (uint16_t)velocity);
    delay(50);
    torqueOn();
}

void AX_12A::setPositionMode(uint32_t velocity, uint32_t acceleration) {
    torqueOff();
    delay(150);
    sdk.setPositionMode(id, -1, true, 6, 8, 2, 0, 1023);
    sdk.write2Byte(id, 32, (uint16_t)velocity);
    delay(50);
    torqueOn();
}

void AX_12A::setPositionMode(int velocity, int acceleration) {
    torqueOff();
    delay(150);
    sdk.setPositionMode(id, -1, true, 6, 8, 2, 0, 1023);
    sdk.write2Byte(id, 32, (uint16_t)velocity);
    delay(50);
    torqueOn();
}

void AX_12A::setVelocityMode() {
    torqueOff();
    delay(150);
    sdk.setVelocityMode(id, -1, true, 6, 8, 2, 0, 0);
    delay(50);
    torqueOn();
}

void AX_12A::setVelocityMode(uint32_t velocity, uint32_t acceleration) {
    torqueOff();
    delay(150);
    sdk.setVelocityMode(id, -1, true, 6, 8, 2, 0, 0);
    delay(50);
    torqueOn();
}

void AX_12A::setVelocityMode(int velocity, int acceleration){
    torqueOff();
    delay(150);
    sdk.setVelocityMode(id, -1, true, 6, 8, 2, 0, 0);
    delay(50);
    torqueOn();
}

void AX_12A::setPositionPID(uint16_t D_GAIN, uint16_t I_GAIN, uint16_t P_GAIN) {
    Serial.println("На AX12-A не поддерживается PID Position");
    return;
}

void AX_12A::setVelocityPID(uint16_t I_GAIN, uint16_t P_GAIN) {
    Serial.println("На AX12-A не поддерживается PID Velocity");
    return;
}

void AX_12A::setGoalPosition(int position) {
    sdk.write2Byte(id, 30, (uint16_t)position);
}

void AX_12A::setGoalPosition(uint32_t position) {
    sdk.write2Byte(id, 30, (uint16_t)position);
}

void AX_12A::setGoalPosition(float radian) {
    sdk.write2Byte(id, 30, (uint16_t)map(radian, 0, 6.28, 0, 4095));
}

void AX_12A::setGoalVelocity(int speed) {
    speed = constrain(speed, -1023, 1023);
    uint16_t value;
    speed >= 0 ? value = speed : value = 1024 + abs(speed);
    sdk.write2Byte(id, 32, (uint16_t)value);
}

void AX_12A::setGoalVelocity(uint32_t speed) {
    speed = constrain(speed, 0, 2047);
    sdk.write2Byte(id, 32, (uint16_t)speed);
}

void AX_12A::setGoalVelocity(float radian) {
    radian = constrain(radian, -6.28, 6.28);

    uint16_t value;

    if (radian >= 0) {
        value = (uint16_t)(radian * 1023.0 / 6.28);
    } else {
        value = 1024 + (uint16_t)((-radian) * 1023.0 / 6.28);
    }

    sdk.write2Byte(id, 32, value);
}

uint32_t AX_12A::getPresentPosition() {
    return sdk.read2Byte(id, 36);
}

float AX_12A::getPresentPositionRad() {
    float normalized = ((float)getPresentPosition() / 4095.0) * 6.28;
    return normalized;
}

int32_t AX_12A::getPresentVelocity() {
    return (int32_t)sdk.read2Byte(id, 38);
}

float AX_12A::getPresentVelocityRad() {
    float normalized = ((float)getPresentVelocity() / 1023.0) * 6.28;
    return normalized;
}