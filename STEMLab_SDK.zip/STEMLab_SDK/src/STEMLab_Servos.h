#pragma once

#include <Arduino.h>

class STEMLab_SDK;

class DynamixelServo {
public:
    DynamixelServo(STEMLab_SDK& sdk, uint8_t id);
    virtual ~DynamixelServo() = default;

    uint8_t getId() const { return id; }

    virtual void torqueOn();
    virtual void torqueOff();

    virtual void setPositionMode();
    virtual void setPositionMode(uint32_t velocity);
    virtual void setPositionMode(uint32_t velocity, uint32_t acceleration);
    virtual void setPositionMode(int velocity, int acceleration);

    virtual void setVelocityMode();
    virtual void setVelocityMode(uint32_t velocity, uint32_t acceleration);
    virtual void setVelocityMode(int velocity, int acceleration);

    virtual void setPositionPID(uint16_t D_GAIN, uint16_t I_GAIN, uint16_t P_GAIN);
    virtual void setVelocityPID(uint16_t I_GAIN, uint16_t P_GAIN);

    virtual void setGoalPosition(int position);
    virtual void setGoalPosition(uint32_t position);
    virtual void setGoalPosition(float radian);

    virtual void setGoalVelocity(int speed);
    virtual void setGoalVelocity(uint32_t speed);
    virtual void setGoalVelocity(float radian);

    virtual uint32_t getPresentPosition();
    virtual float getPresentPositionRad();
    virtual int32_t getPresentVelocity();
    virtual float getPresentVelocityRad();

protected:
    STEMLab_SDK& sdk;
    uint8_t id;
};

struct ServoEntry {
    int key;
    DynamixelServo* value;
};