#include "STEMLab_SDK.h"

//Необходимо выставить текущий baudrate и protocol для устройства
//Их можно определить через пример find_dyn_items
#define BAUDRATE 57600 //Скорость обмена данными устройства
#define PROTOCOL 1.0 //Протокол устройства

STEMLab_SDK sdk(BAUDRATE, PROTOCOL); //Создаем экземпляр класса библиотеки

uint8_t LINE_ID = 10; //Указываем id устройства
uint8_t line_data = 0; //Переменная в которую будет записано значение ИК датчика

void setup() {
  Serial.begin(115200);
  sdk.init(); //Инициализируем работы библиотеки
}

void loop() {
  //Вызываем метод чтения данных с ИК по id и записываем в переменную
  line_data = sdk.getLineData(LINE_ID);
  //Выводим значение ИК датчика
  Serial.println("data: " + String(line_data));
  delay(100);
}