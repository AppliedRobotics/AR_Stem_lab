#include "STEMLab_SDK.h"

//Необходимо выставить текущий baudrate и protocol для устройства
//Их можно определить через пример find_dyn_items
#define BAUDRATE 57600 //Скорость обмена данными устройства
#define PROTOCOL 1.0 //Протокол устройства

STEMLab_SDK sdk(BAUDRATE, PROTOCOL); //Создаем экземпляр класса библиотеки

uint8_t BUTTON_ID = 3; //Указываем id устройства
uint8_t button_data = 0; //Переменная в которую будет записано состояние кнопки

void setup() {
  Serial.begin(115200);
  sdk.init(); //Инициализируем работы библиотеки
}

void loop() {
  //Вызываем метод чтения данных с кнопки по id и записываем в переменную
  button_data = sdk.getButtonData(BUTTON_ID); 
  //Выводим состояние кнопки
  Serial.println("data: " + String(button_data));
  delay(100);
}