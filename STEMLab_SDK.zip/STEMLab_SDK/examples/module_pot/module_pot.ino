#include "STEMLab_SDK.h"

//Необходимо выставить текущий baudrate и protocol для устройства
//Их можно определить через пример find_dyn_items
#define BAUDRATE 57600 //Скорость обмена данными устройства
#define PROTOCOL 1.0 //Протокол устройства

STEMLab_SDK sdk(BAUDRATE, PROTOCOL); //Создаем экземпляр класса библиотеки
 
uint8_t POT_ID = 19; //Указываем id устройства
uint16_t pot_data = 0; //Переменная в которую будет записано значение потенциометра

void setup() {
  Serial.begin(115200);
  sdk.init(); //Инициализируем работы библиотеки
}

void loop() {
  //Вызываем метод чтения данных с потенциометра по id и записываем в переменную
  pot_data = sdk.getPotData(POT_ID);
  //Выводим значение потенциометра
  Serial.println("data: " + String(pot_data));
  delay(100);
}