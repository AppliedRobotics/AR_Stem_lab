#include "STEMLab_SDK.h"

//Необходимо выставить текущий baudrate и protocol для устройства
//Их можно определить через пример find_dyn_items
#define BAUDRATE 1000000 //Скорость обмена данными устройства
#define PROTOCOL 2.0 //Протокол устройства

STEMLab_SDK sdk(BAUDRATE, PROTOCOL); //Создаем экземпляр класса библиотеки

uint8_t SERVO_ID = 1; //Указываем id устройства
uint16_t D_GAIN = 3600, I_GAIN = 0, P_GAIN = 640; //Указываем PID регулятор 
uint16_t current_position = 0; //Переменная текущего положения сервопривода в тиках
double current_position_rad = 0; //Переменная текщуего положения сервопривода в радианах
float goalPositionInRad = 5.01; //Переменная для управление в радианах
uint32_t goalPositionInTicks = 5000; //Переменная для управление в тиках

void setup() {
  Serial.begin(115200);
  sdk.init(); //Инициализируем работы библиотеки
  sdk.torqueOn(SERVO_ID); //Включаем момент на приводе
  sdk.setPositionMode(SERVO_ID); //Выставляем режим работы по положению сервопривода
  sdk.setPostionPID(SERVO_ID, D_GAIN, I_GAIN, P_GAIN); //Выставляем PID регулятор
  //Читаем текущее положение сервопривода в тиках
  current_position = sdk.getPresentPosition(SERVO_ID); 
  Serial.println("current_position in ticks: " + String(current_position));
  //Читаем текущее положение сервопривода в радианах
  current_position_rad = sdk.getPresentPositionRad(SERVO_ID); 
  Serial.println("current_position in rad: " + String(current_position_rad));
  delay(200);
  //Управление сервопривода по тикам 0 - 16383
  sdk.setGoalPosition(SERVO_ID, goalPositionInTicks);
  goalPositionInTicks = 8192;
  delay(2500);
  sdk.setGoalPosition(SERVO_ID, goalPositionInTicks);
  delay(2500);
  //Управление сервопривода по радианам 0 - 6.28
  sdk.setGoalPosition(SERVO_ID, goalPositionInRad);
  goalPositionInRad = 3.14;
  delay(2500);
  sdk.setGoalPosition(SERVO_ID, goalPositionInRad);
  delay(2500);
}

void loop() {
}