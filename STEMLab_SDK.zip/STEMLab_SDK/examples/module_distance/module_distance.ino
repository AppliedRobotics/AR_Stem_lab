#include "STEMLab_SDK.h"

//Необходимо выставить текущий baudrate и protocol для устройства
//Их можно определить через пример find_dyn_items
#define BAUDRATE 57600 //Скорость обмена данными устройства
#define PROTOCOL 1.0 //Протокол устройства

STEMLab_SDK sdk(BAUDRATE, PROTOCOL); //Создаем экземпляр класса библиотеки

uint8_t DIST_ID = 34; //Указываем id устройства
uint16_t dist = 0; //Переменная в которую будет записано расстояние УЗ

void setup() {
  Serial.begin(115200);
  sdk.init(); //Инициализируем работы библиотеки
}

void loop() {
  //Вызываем метод чтения данных с УЗ по id и записываем в переменную
  dist = sdk.getDistance(DIST_ID);
  //Выводим расстояние
  Serial.println("dist: " + String(dist));
  delay(100);
}