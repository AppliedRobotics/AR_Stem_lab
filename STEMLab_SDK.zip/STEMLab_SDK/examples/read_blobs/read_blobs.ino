#include "STEMLab_SDK.h"

//Необходимо выставить текущий baudrate и protocol для устройства
#define BAUDRATE 1000000 //Скорость обмена данными устройства
#define PROTOCOL 1.0 //Протокол устройства
#define CAM_ID 51 //Указываем id устройства

STEMLab_SDK sdk(BAUDRATE, PROTOCOL); //Создаем экземпляр класса библиотеки

uint8_t read_count = 1; //Указываем какое количество блобов читать

void setup() {
  Serial.begin(115200);
  sdk.init(); //Переменная в которую будет записано состояние кнопки
}

void loop() {
  //Вызываем метод чтения блобов
  sdk.readBlobs(CAM_ID, read_count);
  for(uint8_t i = 0; i < read_count; i++){
    Serial.println("type: " + String(sdk.blob[i].type)); //Тип блоба (номер установленного в GUI камеры)
    Serial.println("dummy: " + String(sdk.blob[i].dummy));
    Serial.println("cx: " + String(sdk.blob[i].cx)); //Положение по X
    Serial.println("cy: " + String(sdk.blob[i].cy)); //положение по Y
    Serial.println("area: " + String(sdk.blob[i].area)); //Размер объекта
    Serial.println("left: " + String(sdk.blob[i].left)); //Левая граница блоба
    Serial.println("right: " + String(sdk.blob[i].right)); //Правая граница блоба
    Serial.println("top: " + String(sdk.blob[i].top)); //Верхняя граница блоба
    Serial.println("bottom: " + String(sdk.blob[i].bottom)); //Нижняя граница блоба
  }
  delay(100);
}