#include "STEMLab_SDK.h"

//Необходимо выставить текущий baudrate и protocol для устройства
//Их можно определить через пример find_dyn_items
#define BAUDRATE 1000000 //Скорость обмена данными устройства
#define PROTOCOL 2.0 //Протокол устройства

STEMLab_SDK sdk(BAUDRATE, PROTOCOL); //Создаем экземпляр класса библиотеки

uint8_t servo_id = 1; //Указываем id сервопривода
float new_protocol = 1.0; //Указываем желаемый протокол сервопривода. Доступные значения: 1.0, 2.0

void setup() {
  sdk.init();//Инициализируем работы библиотеки
  //Вызываем метод смены протокола сервопривода
  sdk.changeProtocol(servo_id, new_protocol);
}

void loop() {
}