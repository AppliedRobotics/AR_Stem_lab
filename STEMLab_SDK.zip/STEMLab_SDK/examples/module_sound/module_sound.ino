#include "STEMLab_SDK.h"

//Необходимо выставить текущий baudrate и protocol для устройства
//Их можно определить через пример find_dyn_items
#define BAUDRATE 57600 //Скорость обмена данными устройства
#define PROTOCOL 1.0 //Протокол устройства

STEMLab_SDK sdk(BAUDRATE, PROTOCOL); //Создаем экземпляр класса библиотеки

uint8_t SOUND_ID = 12; //Указываем id устройства
uint8_t sound_level = 0; //Переменная уровеня шума
uint8_t claps = 0; //Переменная количества хлопков
uint8_t sound_threshold = 10; //Переменаня которая устанавливает порог шума для хлопков
uint16_t sound_detect = 0; //Последнее время определения хлопка

void setup() {
  Serial.begin(115200);
  sdk.init(); //Инициализируем работы библиотеки
}

void loop() {
  //Вызываем метод чтения уровня шума
  sound_level = sdk.getSoundLevel(SOUND_ID);
  Serial.println("sound_level: " + String(sound_level));
  //Вызываем метод чтения количетсва хлопков
  claps = sdk.getClapsCount(SOUND_ID);
  Serial.println("claps: " + String(claps));
  //Вызываем метод чтения времени последнего хлопка
  sound_detect = sdk.getLastSoundDetectionTime(SOUND_ID);
  Serial.println("last sound_detect time: " + String(sound_detect));
  //Записываем порог шума для хлопка
  sdk.setSoundThreshold(SOUND_ID, sound_threshold);
  delay(100);
}