#include "STEMLab_SDK.h"

//Необходимо выставить текущий baudrate и protocol для устройства
//Их можно определить через пример find_dyn_items
#define BAUDRATE 57600 //Скорость обмена данными устройства
#define PROTOCOL 1.0 //Протокол устройства

STEMLab_SDK sdk(BAUDRATE, PROTOCOL);//Создаем экземпляр класса библиотеки
uint8_t old_id = 1; //Указвыаем текущий id устройства
uint8_t new_id = 2; //Указвыаем желаемый id устройства
uint16_t periphery_id_reg = 3; //Выбираем регист 3, если работаем с датчиками
uint16_t servo_id_reg = 7; //Выбираем регист 7, если работаем с сервоприводом

void setup() {
  sdk.init(); //Инициализируем работы библиотеки
  //Вызываем метод смены id устройства, выбрав регистр на основе устройства
  sdk.changeId(old_id, periphery_id_reg, new_id);
}

void loop() {
}