#include "STEMLab_SDK.h"

//Необходимо выставить текущий baudrate и protocol для устройства
//Их можно определить через пример find_dyn_items
#define BAUDRATE 1000000 //Скорость обмена данными устройства
#define PROTOCOL 2.0 //Протокол устройства

STEMLab_SDK sdk(BAUDRATE, PROTOCOL);//Создаем экземпляр класса библиотеки

uint8_t SERVO_ID = 1; //Указываем id устройства
uint16_t I_GAIN = 1000, P_GAIN = 100; //Указываем ID регулятор 
int32_t current_velocity_ticks = 0; //Переменная текущей скорости сервопривода в тиках от -1048 до 1048
float current_velocity_rad = 0; //Переменная текущей скорости сервопривода в радианах от -6.28 до 6.28
uint32_t goalVelocity = -100; //Переменная управления в тиках
float goalVelocityRad = 3.14; //Переменная управления в радианах

void setup() {
  Serial.begin(115200);
  sdk.init();//Инициализируем работы библиотеки
  sdk.torqueOn(SERVO_ID); //Включаем момент на приводе
  sdk.setVelocityMode(SERVO_ID); //Выставляем режим работы шарнира сервопривода
  sdk.setVelocityPID(SERVO_ID, I_GAIN, P_GAIN); //Выставляем ID регулятор
  //Управление с помощью тиков
  sdk.setGoalVelocity(SERVO_ID, goalVelocity);
  delay(2500);
  //Читаем текущее положение сервопривода в тиках
  current_velocity_ticks = sdk.getPresentVelocity(SERVO_ID); 
  Serial.println("current_velocity in ticks: " + String(current_velocity_ticks));
  //Читаем текущее положение сервопривода в радианах
  current_velocity_rad = sdk.getPresentVelocityRad(SERVO_ID); 
  Serial.println("current_velocity in rads: " + String(current_velocity_rad));
  goalVelocity = 0;
  sdk.setGoalVelocity(SERVO_ID, goalVelocity);
  delay(1000);
  //Управление с помощью радианов
  sdk.setGoalVelocity(SERVO_ID, goalVelocityRad);
  delay(2500);
  //Читаем текущее положение сервопривода в тиках
  current_velocity_ticks = sdk.getPresentVelocity(SERVO_ID); 
  Serial.println("current_velocity in ticks: " + String(current_velocity_ticks));
  //Читаем текущее положение сервопривода в радианах
  current_velocity_rad = sdk.getPresentVelocityRad(SERVO_ID); 
  Serial.println("current_velocity in rads: " + String(current_velocity_rad));
  goalVelocityRad = 0;
  sdk.setGoalVelocity(SERVO_ID, goalVelocityRad);
}

void loop() {
}