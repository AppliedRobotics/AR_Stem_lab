#include "STEMLab_SDK.h"

//Необходимо выставить текущий baudrate и protocol для устройства
//Их можно определить через пример find_dyn_items
#define BAUDRATE 57600 //Скорость обмена данными устройства
#define PROTOCOL 1.0 //Протокол устройства

STEMLab_SDK sdk(BAUDRATE, PROTOCOL); //Создаем экземпляр класса библиотеки

uint8_t id = 1; //Указываем id устройства
uint16_t periphery_baud_reg = 4; //Выбираем регист 4, если работаем с датчиками
uint16_t servo_id_reg = 8; //Выбираем регист 8, если работаем с сервоприводом

void setup() {
  sdk.init(); //Инициализируем работы библиотеки
  //Вызываем метод смены скорости обмена данными
  //Доступные значения: 57600, 115200, 1000000
  sdk.changeBaudrate(id, periphery_baud_reg, 57600);
}

void loop() {
}